import torch
import torch.nn as nn
import torch.optim as optim
import json
import numpy as np
from typing import Dict, List, Tuple
import random

class ColorSchemeModel(nn.Module):
    """
    Простая нейронная сеть для генерации цветовых схем по рейтингу
    Архитектура: Feed-Forward с 3 скрытыми слоями
    """
    
    def __init__(self, input_dim: int = 1, hidden_dim: int = 64, output_dim: int = 9):
        super(ColorSchemeModel, self).__init__()
        
        # input_dim = 1 (только рейтинг)
        # output_dim = 9 (3 цвета × 3 RGB канала)
        
        self.network = nn.Sequential(
            # Входной слой
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.1),
            
            # Скрытый слой 1
            nn.Linear(hidden_dim, hidden_dim * 2),
            nn.ReLU(),
            nn.Dropout(0.1),
            
            # Скрытый слой 2  
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.1),
            
            # Выходной слой
            nn.Linear(hidden_dim, output_dim),
            nn.Sigmoid()  # Нормализация в диапазон [0, 1] для RGB
        )
        
    def forward(self, rating: torch.Tensor) -> torch.Tensor:
        """
        Прямой проход через сеть
        
        Args:
            rating: тензор с рейтингами [batch_size, 1]
            
        Returns:
            RGB значения для 3 цветов [batch_size, 9]
        """
        # Нормализация рейтинга в диапазон [0, 1]
        normalized_rating = rating / 10.0
        
        # Прямой проход
        output = self.network(normalized_rating)
        
        return output
    
    def predict_colors(self, rating: float) -> Dict[str, str]:
        """
        Предсказание цветовой схемы для одного рейтинга
        
        Args:
            rating: рейтинг фильма (0.0 - 10.0)
            
        Returns:
            Словарь с цветами в HEX формате
        """
        self.eval()
        
        with torch.no_grad():
            # Подготовка входа
            rating_tensor = torch.tensor([[rating]], dtype=torch.float32)
            
            # Получение предсказания
            rgb_values = self.forward(rating_tensor)
            
            # Преобразование в RGB (0-255)
            rgb_values = (rgb_values * 255).int().squeeze().numpy()
            
            # Разделение на 3 цвета
            primary_rgb = rgb_values[0:3]
            secondary_rgb = rgb_values[3:6] 
            accent_rgb = rgb_values[6:9]
            
            # Конвертация в HEX
            colors = {
                'primary': self._rgb_to_hex(primary_rgb),
                'secondary': self._rgb_to_hex(secondary_rgb),
                'accent': self._rgb_to_hex(accent_rgb)
            }
            
            return colors
    
    def _rgb_to_hex(self, rgb: np.ndarray) -> str:
        """Конвертация RGB в HEX"""
        return f"#{rgb[0]:02X}{rgb[1]:02X}{rgb[2]:02X}"


class ColorSchemeTrainer:
    """
    Класс для обучения модели цветовых схем
    """
    
    def __init__(self, model: ColorSchemeModel):
        self.model = model
        self.optimizer = optim.Adam(model.parameters(), lr=0.001)
        self.criterion = nn.MSELoss()
        
    def hex_to_rgb_normalized(self, hex_color: str) -> List[float]:
        """Конвертация HEX в нормализованные RGB значения [0, 1]"""
        hex_color = hex_color.lstrip('#')
        rgb = [int(hex_color[i:i+2], 16) / 255.0 for i in (0, 2, 4)]
        return rgb
    
    def prepare_training_data(self, dataset_path: str) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Подготовка данных для обучения из JSON файла
        
        Returns:
            X: рейтинги [num_samples, 1] 
            y: RGB значения для 3 цветов [num_samples, 9]
        """
        with open(dataset_path, 'r', encoding='utf-8') as f:
            dataset = json.load(f)
        
        X = []
        y = []
        
        for sample in dataset:
            # Входной рейтинг
            rating = sample['input']['rating']
            X.append([rating])
            
            # Целевые RGB значения (3 цвета × 3 канала = 9 значений)
            colors = sample['output']
            rgb_values = []
            
            # Конвертация каждого цвета в RGB
            for color_key in ['primary', 'secondary', 'accent']:
                rgb = self.hex_to_rgb_normalized(colors[color_key])
                rgb_values.extend(rgb)
            
            y.append(rgb_values)
        
        X_tensor = torch.tensor(X, dtype=torch.float32)
        y_tensor = torch.tensor(y, dtype=torch.float32)
        
        return X_tensor, y_tensor
    
    def train(self, train_data_path: str, epochs: int = 1000, batch_size: int = 32):
        """
        Обучение модели
        
        Args:
            train_data_path: путь к файлу с обучающими данными
            epochs: количество эпох
            batch_size: размер батча
        """
        print("Loading training data...")
        X_train, y_train = self.prepare_training_data(train_data_path)
        
        print(f"Training data shape: X={X_train.shape}, y={y_train.shape}")
        print(f"Starting training for {epochs} epochs...")
        
        self.model.train()
        
        # Обучающий цикл
        for epoch in range(epochs):
            total_loss = 0.0
            num_batches = len(X_train) // batch_size
            
            # Перемешиваем данные
            indices = torch.randperm(len(X_train))
            X_train = X_train[indices]
            y_train = y_train[indices]
            
            for i in range(0, len(X_train), batch_size):
                # Получаем батч
                batch_X = X_train[i:i+batch_size]
                batch_y = y_train[i:i+batch_size]
                
                # Обнуляем градиенты
                self.optimizer.zero_grad()
                
                # Прямой проход
                predictions = self.model(batch_X)
                
                # Вычисляем ошибку
                loss = self.criterion(predictions, batch_y)
                
                # Обратный проход
                loss.backward()
                self.optimizer.step()
                
                total_loss += loss.item()
            
            avg_loss = total_loss / num_batches if num_batches > 0 else total_loss
            
            # Выводим прогресс каждые 100 эпох
            if epoch % 100 == 0:
                print(f"Epoch {epoch}/{epochs}, Loss: {avg_loss:.6f}")
        
        print("Training completed!")
    
    def evaluate(self, validation_data_path: str):
        """
        Оценка качества модели на валидационных данных
        """
        print("Evaluating model...")
        
        with open(validation_data_path, 'r', encoding='utf-8') as f:
            validation_data = json.load(f)
        
        self.model.eval()
        
        for i, sample in enumerate(validation_data):
            rating = sample['input']['rating']
            expected_colors = sample['output']
            
            # Получаем предсказание
            predicted_colors = self.model.predict_colors(rating)
            
            print(f"\nTest {i+1}:")
            print(f"Rating: {rating}")
            print(f"Expected: {expected_colors}")
            print(f"Predicted: {predicted_colors}")
            
            # Простая метрика сходства (по категории цвета)
            expected_category = self._get_color_category(expected_colors['primary'])
            predicted_category = self._get_color_category(predicted_colors['primary'])
            
            match = "✅" if expected_category == predicted_category else "❌"
            print(f"Color category: {expected_category} vs {predicted_category} {match}")
    
    def _get_color_category(self, hex_color: str) -> str:
        """Определение категории цвета (GREEN, BLUE, RED)"""
        hex_color = hex_color.lstrip('#')
        r, g, b = [int(hex_color[i:i+2], 16) for i in (0, 2, 4)]
        
        if g > r and g > b:
            return "GREEN"
        elif b > r and b > g:
            return "BLUE"
        elif r > g and r > b:
            return "RED"
        else:
            return "MIXED"
    
    def save_model(self, path: str = "color_scheme_model.pth"):
        """Сохранение обученной модели"""
        torch.save(self.model.state_dict(), path)
        print(f"Model saved to {path}")
    
    def load_model(self, path: str = "color_scheme_model.pth"):
        """Загрузка обученной модели"""
        self.model.load_state_dict(torch.load(path))
        self.model.eval()
        print(f"Model loaded from {path}")


# Пример использования
if __name__ == "__main__":
    # Создание модели
    model = ColorSchemeModel()
    trainer = ColorSchemeTrainer(model)
    
    # Обучение
    trainer.train("train_dataset.json", epochs=500, batch_size=64)
    
    # Оценка
    trainer.evaluate("validation_dataset.json")
    
    # Сохранение модели
    trainer.save_model()
    
    # Тестирование на произвольных значениях
    print("\n=== Testing on custom ratings ===")
    test_ratings = [0.5, 3.2, 6.8, 8.9, 10.0]
    
    for rating in test_ratings:
        colors = model.predict_colors(rating)
        category = trainer._get_color_category(colors['primary'])
        print(f"Rating {rating}: {colors} -> {category}")