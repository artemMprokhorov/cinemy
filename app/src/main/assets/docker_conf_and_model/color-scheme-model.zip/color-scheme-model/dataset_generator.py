import json
import random
import numpy as np
from typing import List, Dict, Tuple

class ColorSchemeDatasetGenerator:
    """
    Генератор синтетического датасета для обучения модели цветовых схем
    """
    
    def __init__(self):
        # Базовые цвета из ваших правил
        self.color_rules = {
            'HIGH': {
                'primary': '#4CAF50',    # Зеленый
                'secondary': '#66BB6A',
                'accent': '#81C784',
                'range': (8.0, 10.0)
            },
            'MEDIUM': {
                'primary': '#2196F3',    # Синий  
                'secondary': '#42A5F5',
                'accent': '#64B5F6',
                'range': (6.0, 7.9)
            },
            'LOW': {
                'primary': '#F44336',    # Красный
                'secondary': '#EF5350', 
                'accent': '#E57373',
                'range': (0.0, 5.9)
            }
        }
        
        # Вариации цветов для увеличения разнообразия датасета
        self.color_variations = {
            'HIGH': [
                {'primary': '#4CAF50', 'secondary': '#66BB6A', 'accent': '#81C784'},
                {'primary': '#388E3C', 'secondary': '#4CAF50', 'accent': '#66BB6A'},
                {'primary': '#2E7D32', 'secondary': '#388E3C', 'accent': '#4CAF50'},
                {'primary': '#1B5E20', 'secondary': '#2E7D32', 'accent': '#388E3C'},
                {'primary': '#8BC34A', 'secondary': '#9CCC65', 'accent': '#AED581'}
            ],
            'MEDIUM': [
                {'primary': '#2196F3', 'secondary': '#42A5F5', 'accent': '#64B5F6'},
                {'primary': '#1976D2', 'secondary': '#2196F3', 'accent': '#42A5F5'},
                {'primary': '#1565C0', 'secondary': '#1976D2', 'accent': '#2196F3'},
                {'primary': '#0D47A1', 'secondary': '#1565C0', 'accent': '#1976D2'},
                {'primary': '#03A9F4', 'secondary': '#29B6F6', 'accent': '#4FC3F7'}
            ],
            'LOW': [
                {'primary': '#F44336', 'secondary': '#EF5350', 'accent': '#E57373'},
                {'primary': '#D32F2F', 'secondary': '#F44336', 'accent': '#EF5350'},
                {'primary': '#C62828', 'secondary': '#D32F2F', 'accent': '#F44336'},
                {'primary': '#B71C1C', 'secondary': '#C62828', 'accent': '#D32F2F'},
                {'primary': '#FF5722', 'secondary': '#FF7043', 'accent': '#FF8A65'}
            ]
        }
    
    def hex_to_rgb(self, hex_color: str) -> Tuple[int, int, int]:
        """Конвертация HEX в RGB"""
        hex_color = hex_color.lstrip('#')
        return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
    
    def rgb_to_hex(self, rgb: Tuple[int, int, int]) -> str:
        """Конвертация RGB в HEX"""
        return f"#{rgb[0]:02x}{rgb[1]:02x}{rgb[2]:02x}".upper()
    
    def add_color_noise(self, hex_color: str, noise_level: int = 15) -> str:
        """Добавление небольшого шума к цвету для вариативности"""
        r, g, b = self.hex_to_rgb(hex_color)
        
        # Добавляем случайный шум в пределах noise_level
        r = max(0, min(255, r + random.randint(-noise_level, noise_level)))
        g = max(0, min(255, g + random.randint(-noise_level, noise_level)))
        b = max(0, min(255, b + random.randint(-noise_level, noise_level)))
        
        return self.rgb_to_hex((r, g, b))
    
    def get_rating_category(self, rating: float) -> str:
        """Определение категории по рейтингу"""
        if rating >= 8.0:
            return 'HIGH'
        elif rating >= 6.0:
            return 'MEDIUM'
        else:
            return 'LOW'
    
    def generate_colors_for_rating(self, rating: float, add_noise: bool = True) -> Dict[str, str]:
        """Генерация цветов для конкретного рейтинга"""
        category = self.get_rating_category(rating)
        
        # Выбираем случайную вариацию цветов для категории
        variations = self.color_variations[category]
        base_colors = random.choice(variations)
        
        if add_noise:
            # Добавляем небольшой шум для разнообразия
            noise_level = 10 if category == 'MEDIUM' else 15
            return {
                'primary': self.add_color_noise(base_colors['primary'], noise_level),
                'secondary': self.add_color_noise(base_colors['secondary'], noise_level),
                'accent': self.add_color_noise(base_colors['accent'], noise_level)
            }
        else:
            return base_colors.copy()
    
    def generate_dataset(self, size: int = 10000) -> List[Dict]:
        """Генерация полного датасета"""
        dataset = []
        
        for i in range(size):
            # Генерируем случайный рейтинг
            if i < size // 3:
                # 1/3 - HIGH ratings
                rating = round(random.uniform(8.0, 10.0), 1)
            elif i < 2 * size // 3:
                # 1/3 - MEDIUM ratings  
                rating = round(random.uniform(6.0, 7.9), 1)
            else:
                # 1/3 - LOW ratings
                rating = round(random.uniform(0.0, 5.9), 1)
            
            # Генерируем соответствующие цвета
            colors = self.generate_colors_for_rating(rating, add_noise=True)
            
            # Создаем пример для обучения
            sample = {
                'input': {
                    'rating': rating,
                    'category': self.get_rating_category(rating)
                },
                'output': colors,
                'metadata': {
                    'id': i,
                    'rating_range': f"{rating:.1f}",
                    'color_category': self.get_rating_category(rating)
                }
            }
            
            dataset.append(sample)
        
        return dataset
    
    def save_dataset(self, dataset: List[Dict], filename: str = 'color_scheme_dataset.json'):
        """Сохранение датасета в файл"""
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(dataset, f, indent=2, ensure_ascii=False)
        
        print(f"Dataset saved: {filename}")
        print(f"Total samples: {len(dataset)}")
        
        # Статистика по категориям
        categories = {}
        for sample in dataset:
            cat = sample['input']['category']
            categories[cat] = categories.get(cat, 0) + 1
        
        print("Category distribution:")
        for cat, count in categories.items():
            print(f"  {cat}: {count} samples ({count/len(dataset)*100:.1f}%)")
    
    def create_validation_samples(self) -> List[Dict]:
        """Создание образцов для валидации (точные значения без шума)"""
        validation_samples = []
        
        # Точные тестовые значения
        test_ratings = [
            # HIGH category
            8.0, 8.5, 9.0, 9.5, 10.0,
            # MEDIUM category  
            6.0, 6.5, 7.0, 7.5, 7.9,
            # LOW category
            0.0, 1.0, 2.5, 4.0, 5.9
        ]
        
        for rating in test_ratings:
            colors = self.generate_colors_for_rating(rating, add_noise=False)
            sample = {
                'input': {
                    'rating': rating,
                    'category': self.get_rating_category(rating)
                },
                'output': colors,
                'expected_category': self.get_rating_category(rating)
            }
            validation_samples.append(sample)
        
        return validation_samples

# Пример использования
if __name__ == "__main__":
    generator = ColorSchemeDatasetGenerator()
    
    # Создаем обучающий датасет
    dataset = generator.generate_dataset(size=10000)
    generator.save_dataset(dataset, 'train_dataset.json')
    
    # Создаем валидационный датасет
    validation = generator.create_validation_samples()
    generator.save_dataset(validation, 'validation_dataset.json')
    
    # Показываем примеры
    print("\nSample data:")
    for i in range(3):
        sample = dataset[i]
        print(f"Rating: {sample['input']['rating']}")
        print(f"Category: {sample['input']['category']}")
        print(f"Colors: {sample['output']}")
        print("---")