from flask import Flask, request, jsonify
import torch
import json
import os
from color_model import ColorSchemeModel
import logging

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)

class ColorSchemeAPI:
    """
    REST API для генерации цветовых схем
    """
    
    def __init__(self, model_path: str = "color_scheme_model.pth"):
        self.model = ColorSchemeModel()
        self.model_path = model_path
        self.load_model()
    
    def load_model(self):
        """Загрузка обученной модели"""
        try:
            if os.path.exists(self.model_path):
                self.model.load_state_dict(torch.load(self.model_path, map_location='cpu'))
                self.model.eval()
                logger.info(f"Model loaded successfully from {self.model_path}")
            else:
                logger.error(f"Model file not found: {self.model_path}")
                raise FileNotFoundError(f"Model file not found: {self.model_path}")
        except Exception as e:
            logger.error(f"Failed to load model: {e}")
            raise e
    
    def generate_color_scheme(self, rating: float) -> dict:
        """
        Генерация цветовой схемы для рейтинга
        
        Args:
            rating: рейтинг фильма (0.0 - 10.0)
            
        Returns:
            dict: цветовая схема в формате {"primary": "#HEX", ...}
        """
        try:
            # Валидация входного значения
            if not isinstance(rating, (int, float)):
                raise ValueError("Rating must be a number")
            
            rating = float(rating)
            if rating < 0.0 or rating > 10.0:
                raise ValueError("Rating must be between 0.0 and 10.0")
            
            # Генерация цветов
            colors = self.model.predict_colors(rating)
            
            logger.info(f"Generated colors for rating {rating}: {colors}")
            return colors
            
        except Exception as e:
            logger.error(f"Error generating color scheme: {e}")
            raise e
    
    def get_fallback_colors(self, rating: float) -> dict:
        """
        Fallback цветовая схема на основе базовых правил
        (если модель недоступна)
        """
        if rating >= 8.0:
            return {
                "primary": "#4CAF50",
                "secondary": "#66BB6A", 
                "accent": "#81C784"
            }
        elif rating >= 6.0:
            return {
                "primary": "#2196F3",
                "secondary": "#42A5F5",
                "accent": "#64B5F6"
            }
        else:
            return {
                "primary": "#F44336",
                "secondary": "#EF5350",
                "accent": "#E57373"
            }

# Глобальный экземпляр API
color_api = None

def initialize_api():
    """Инициализация API при запуске сервера"""
    global color_api
    try:
        color_api = ColorSchemeAPI()
        logger.info("Color Scheme API initialized successfully")
    except Exception as e:
        logger.error(f"Failed to initialize API: {e}")
        color_api = None

@app.route('/health', methods=['GET'])
def health_check():
    """Проверка состояния сервера"""
    return jsonify({
        "status": "healthy",
        "model_loaded": color_api is not None,
        "version": "1.0.0"
    })

@app.route('/generate', methods=['POST'])
def generate_color_scheme():
    """
    Основной endpoint для генерации цветовых схем
    
    Expected JSON:
    {
        "rating": 8.5
    }
    
    Returns:
    {
        "primary": "#4CAF50",
        "secondary": "#66BB6A", 
        "accent": "#81C784"
    }
    """
    try:
        # Парсинг входных данных
        data = request.get_json()
        
        if not data:
            return jsonify({
                "error": "No JSON data provided"
            }), 400
        
        if 'rating' not in data:
            return jsonify({
                "error": "Missing 'rating' field in request"
            }), 400
        
        rating = data['rating']
        
        # Генерация цветовой схемы
        if color_api:
            try:
                colors = color_api.generate_color_scheme(rating)
            except Exception as e:
                logger.warning(f"Model failed, using fallback: {e}")
                colors = color_api.get_fallback_colors(rating)
        else:
            # Fallback если модель не загружена
            logger.warning("Model not loaded, using fallback colors")
            if rating >= 8.0:
                colors = {"primary": "#4CAF50", "secondary": "#66BB6A", "accent": "#81C784"}
            elif rating >= 6.0:
                colors = {"primary": "#2196F3", "secondary": "#42A5F5", "accent": "#64B5F6"}
            else:
                colors = {"primary": "#F44336", "secondary": "#EF5350", "accent": "#E57373"}
        
        # Успешный ответ
        response = {
            **colors,
            "metadata": {
                "rating": rating,
                "model_used": color_api is not None,
                "category": "HIGH" if rating >= 8.0 else ("MEDIUM" if rating >= 6.0 else "LOW")
            }
        }
        
        return jsonify(response)
        
    except ValueError as e:
        return jsonify({
            "error": f"Invalid input: {e}"
        }), 400
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        return jsonify({
            "error": "Internal server error"
        }), 500

@app.route('/generate-batch', methods=['POST'])
def generate_batch_color_schemes():
    """
    Генерация цветовых схем для множества рейтингов
    
    Expected JSON:
    {
        "ratings": [8.5, 6.2, 3.1]
    }
    
    Returns:
    {
        "results": [
            {"rating": 8.5, "colors": {"primary": "#4CAF50", ...}},
            ...
        ]
    }
    """
    try:
        data = request.get_json()
        
        if not data or 'ratings' not in data:
            return jsonify({
                "error": "Missing 'ratings' field in request"
            }), 400
        
        ratings = data['ratings']
        
        if not isinstance(ratings, list):
            return jsonify({
                "error": "'ratings' must be a list"
            }), 400
        
        if len(ratings) > 100:
            return jsonify({
                "error": "Maximum 100 ratings per batch request"
            }), 400
        
        # Генерация цветов для каждого рейтинга
        results = []
        
        for rating in ratings:
            try:
                if color_api:
                    colors = color_api.generate_color_scheme(rating)
                else:
                    # Fallback
                    if rating >= 8.0:
                        colors = {"primary": "#4CAF50", "secondary": "#66BB6A", "accent": "#81C784"}
                    elif rating >= 6.0:
                        colors = {"primary": "#2196F3", "secondary": "#42A5F5", "accent": "#64B5F6"}
                    else:
                        colors = {"primary": "#F44336", "secondary": "#EF5350", "accent": "#E57373"}
                
                results.append({
                    "rating": rating,
                    "colors": colors,
                    "category": "HIGH" if rating >= 8.0 else ("MEDIUM" if rating >= 6.0 else "LOW")
                })
                
            except Exception as e:
                logger.error(f"Error processing rating {rating}: {e}")
                results.append({
                    "rating": rating,
                    "error": str(e)
                })
        
        return jsonify({
            "results": results,
            "processed": len(results),
            "model_used": color_api is not None
        })
        
    except Exception as e:
        logger.error(f"Batch processing error: {e}")
        return jsonify({
            "error": "Internal server error"
        }), 500

@app.route('/test', methods=['GET'])
def test_endpoint():
    """Тестовый endpoint с примерами"""
    test_ratings = [0.5, 3.2, 6.8, 8.9, 10.0]
    test_results = []
    
    for rating in test_ratings:
        try:
            if color_api:
                colors = color_api.generate_color_scheme(rating)
            else:
                # Fallback
                if rating >= 8.0:
                    colors = {"primary": "#4CAF50", "secondary": "#66BB6A", "accent": "#81C784"}
                elif rating >= 6.0:
                    colors = {"primary": "#2196F3", "secondary": "#42A5F5", "accent": "#64B5F6"}
                else:
                    colors = {"primary": "#F44336", "secondary": "#EF5350", "accent": "#E57373"}
            
            test_results.append({
                "rating": rating,
                "colors": colors
            })
        except Exception as e:
            test_results.append({
                "rating": rating,
                "error": str(e)
            })
    
    return jsonify({
        "test_results": test_results,
        "model_loaded": color_api is not None,
        "server_status": "running"
    })

@app.errorhandler(404)
def not_found(error):
    return jsonify({
        "error": "Endpoint not found",
        "available_endpoints": [
            "GET /health",
            "POST /generate",
            "POST /generate-batch", 
            "GET /test"
        ]
    }), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({
        "error": "Internal server error",
        "message": "Please check server logs"
    }), 500

if __name__ == '__main__':
    # Инициализация API при запуске
    initialize_api()
    
    # Запуск сервера
    port = int(os.environ.get('PORT', 8081))
    debug = os.environ.get('DEBUG', 'False').lower() == 'true'
    
    logger.info(f"Starting Color Scheme API server on port {port}")
    logger.info(f"Debug mode: {debug}")
    
    app.run(
        host='0.0.0.0',  # Доступ извне контейнера
        port=port,
        debug=debug
    )